Simple Python Web Server
========================

This is the source code for howCode's simple Python Web Server.

You can watch the video that accompanies this source code here: https://youtu.be/hFNZ6kdBgO0
